# setup_genotype_phenotype.py
"""
Setup script for genotype-phenotype mapping functionality
Run this to generate synthetic data and train the model
"""

import os
import subprocess
import sys

def run_setup():
    print("Setting up Genotype-Phenotype Mapping...")
    
    # Change to the project directory
    project_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(project_dir)
    
    # Step 1: Generate synthetic data
    print("\n1. Generating synthetic genetic data...")
    try:
        subprocess.run([sys.executable, "data/make_synthetic_geno1.py"], check=True)
        print("✓ Synthetic data generated successfully!")
    except subprocess.CalledProcessError as e:
        print(f"✗ Error generating data: {e}")
        return False
    
    # Step 2: Train the model
    print("\n2. Training genotype-phenotype model...")
    try:
        subprocess.run([sys.executable, "traning_testing/train_genotype_phenotype.py"], check=True)
        print("✓ Model trained successfully!")
    except subprocess.CalledProcessError as e:
        print(f"✗ Error training model: {e}")
        return False
    
    print("\n✓ Setup completed! You can now use the Genotype-Phenotype Mapper.")
    print("Run: streamlit run app.py")
    return True

if __name__ == "__main__":
    run_setup()