# test_genotype_integration.py
"""
Test script to verify genotype-phenotype integration
"""

import os
import sys
import pandas as pd

def test_data_files():
    """Test if data files exist"""
    print("Testing data files...")
    
    data_file = "data/genotype_train.csv"
    if os.path.exists(data_file):
        df = pd.read_csv(data_file)
        print(f"+ Data file exists: {data_file}")
        print(f"  - Shape: {df.shape}")
        print(f"  - Columns: {list(df.columns)}")
        print(f"  - Phenotypes: {df['Phenotype_Label'].unique()}")
        return True
    else:
        print(f"- Data file missing: {data_file}")
        return False

def test_model_files():
    """Test if model files exist"""
    print("\nTesting model files...")
    
    model_files = [
        "models/genotype_phenotype_model.pkl",
        "models/genotype_phenotype_encoders.pkl"
    ]
    
    all_exist = True
    for file_path in model_files:
        if os.path.exists(file_path):
            print(f"+ Model file exists: {file_path}")
        else:
            print(f"- Model file missing: {file_path}")
            all_exist = False
    
    return all_exist

def test_prediction_function():
    """Test the prediction function"""
    print("\nTesting prediction function...")
    
    try:
        from traning_testing.predict_genotype_phenotype import predict_trait
        
        # Test prediction
        label, confidence, prob_dict = predict_trait(
            gene_id="TP53",
            mutation="A>T", 
            expression_level=0.72,
            impact_score=0.81
        )
        
        print(f"+ Prediction successful:")
        print(f"  - Predicted phenotype: {label}")
        print(f"  - Confidence: {confidence:.4f}")
        print(f"  - All probabilities: {list(prob_dict.keys())}")
        return True
        
    except Exception as e:
        print(f"- Prediction failed: {e}")
        return False

def test_streamlit_page():
    """Test if Streamlit page can be imported"""
    print("\nTesting Streamlit page import...")
    
    try:
        # Add pages directory to path
        sys.path.append('pages')
        
        # Test basic imports that the page uses
        import streamlit as st
        import pandas as pd
        import numpy as np
        from traning_testing.predict_genotype_phenotype import predict_trait
        
        print("+ All Streamlit page imports successful")
        return True
        
    except Exception as e:
        print(f"- Streamlit page import failed: {e}")
        return False

def main():
    """Run all tests"""
    print("=" * 50)
    print("GENOTYPE-PHENOTYPE INTEGRATION TEST")
    print("=" * 50)
    
    tests = [
        test_data_files,
        test_model_files, 
        test_prediction_function,
        test_streamlit_page
    ]
    
    results = []
    for test in tests:
        results.append(test())
    
    print("\n" + "=" * 50)
    print("TEST SUMMARY")
    print("=" * 50)
    
    passed = sum(results)
    total = len(results)
    
    print(f"Tests passed: {passed}/{total}")
    
    if passed == total:
        print("+ ALL TESTS PASSED - Integration successful!")
        print("\nYou can now run: streamlit run app.py")
        print("And navigate to 'Genotype -> Phenotype Mapper'")
    else:
        print("- Some tests failed - Check the errors above")
        
        if not results[0] or not results[1]:
            print("\nTo fix missing files, run:")
            print("python setup_genotype_phenotype.py")

if __name__ == "__main__":
    main()