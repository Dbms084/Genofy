# train_model.py
# -----------------------------
# Trains an ML regression model to predict mutation impact scores
# using genetic and expression-based features.
# -----------------------------

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, r2_score
import joblib
import os

# 1️⃣ Load Dataset
def load_data(file_path):
    """
    Load genetic dataset from CSV file.
    Expected columns:
    ['Gene', 'Mutation', 'Sequence', 'Expression_Level',
     'GC_Content', 'Mutation_Frequency', 'Impact_Score', 'Category']
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"❌ Dataset not found at {file_path}")
    
    df = pd.read_csv(file_path)
    print("✅ Data Loaded Successfully!")
    print("📊 Dataset Shape:", df.shape)
    return df


# 2️⃣ Preprocess Data
def preprocess_data(df):
    """
    Drop text columns (like Gene, Sequence),
    encode categorical variables (Mutation, Category),
    and scale numerical features.
    """
    # Drop unused text columns
    df = df.drop(columns=['Gene', 'Sequence'], errors='ignore')

    # Separate features and target
    X = df.drop(columns=['Impact_Score'])
    y = df['Impact_Score']

    # One-hot encode categorical columns (Mutation, Category)
    categorical_cols = [col for col in ['Mutation', 'Category'] if col in X.columns]
    X = pd.get_dummies(X, columns=categorical_cols, drop_first=True)

    # Scale numerical features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    return X_scaled, y, scaler, X.columns.tolist()


# 3️⃣ Train Model
def train_model(X, y):
    """
    Train a RandomForestRegressor and return the model.
    """
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    model = RandomForestRegressor(n_estimators=150, random_state=42)
    model.fit(X_train, y_train)

    # Evaluate model
    y_pred = model.predict(X_test)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    r2 = r2_score(y_test, y_pred)

    print("✅ Model Training Completed")
    print(f"📊 RMSE: {rmse:.4f}")
    print(f"📈 R² Score: {r2:.4f}")

    return model, rmse, r2


# 4️⃣ Save Model, Scaler, and Feature Names
def save_model(model, scaler, feature_names):
    os.makedirs('models', exist_ok=True)
    joblib.dump(model, 'models/model.pkl')
    joblib.dump(scaler, 'models/scaler.pkl')
    joblib.dump(feature_names, 'models/feature_names.pkl')
    print("💾 All model components saved in 'models/' folder!")


# 5️⃣ Main Function
if __name__ == "__main__":
    data_path = "C:/Users/dhrit/Downloads/new/data/genetic_dataset_ml.csv"  # ✅ Correct dataset path
    df = load_data(data_path)

    X_scaled, y, scaler, feature_names = preprocess_data(df)
    model, rmse, r2 = train_model(X_scaled, y)
    save_model(model, scaler, feature_names)
