# ----------------------------------------------------
# __init__.py - Training Modules Package
# ----------------------------------------------------
# This file turns 'training_modules' into a Python package
# and exposes the stability index training module.
# ----------------------------------------------------

from .stability_index.train_model import train_stability_model

__all__ = [
    "train_stability_model"
]
