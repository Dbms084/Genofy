# app.py
# --------------------------------------------------------
# Streamlit web app for Genetic Pathway Predictor
# Modern Dark Theme Design inspired by Genofy
# --------------------------------------------------------

import streamlit as st
import pandas as pd
import joblib
import os
from traning_testing.train_model import load_data, preprocess_data, train_model, save_model
from traning_testing.predict import load_components, prepare_data, predict

# --------------------------------------------------------
# Page Configuration
# --------------------------------------------------------
st.set_page_config(
    page_title="Genofy - Genetic Intelligence",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --------------------------------------------------------
# Modern Dark Theme CSS (Genofy-inspired)
# --------------------------------------------------------
st.markdown("""
<style>
    /* Import Google Fonts */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');
    
    /* Global Styles */
    * {
        font-family: 'Inter', sans-serif;
    }
    
    /* Main Background - Dark Navy */
    .stApp {
        background: linear-gradient(180deg, #0a1628 0%, #111c30 50%, #0f1b2d 100%);
    }
    
    /* Remove default padding */
    .block-container {
        padding-top: 3rem;
        padding-bottom: 3rem;
        max-width: 1400px;
    }
    
    /* Sidebar Styling - Darker shade */
    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, #080d18 0%, #0d1420 100%);
        border-right: 1px solid rgba(255, 255, 255, 0.05);
    }
    
    [data-testid="stSidebar"] .stRadio > label {
        color: #e2e8f0;
        font-size: 16px;
        font-weight: 600;
        padding: 10px 0;
        text-transform: uppercase;
        letter-spacing: 1px;
        font-size: 13px;
    }
    
    /* Navigation Cards in Sidebar */
    [data-testid="stSidebar"] [role="radiogroup"] label {
        background: rgba(255, 255, 255, 0.03);
        padding: 16px 18px;
        border-radius: 12px;
        margin: 8px 0;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        cursor: pointer;
        color: #94a3b8;
        font-size: 15px;
        border: 1px solid rgba(255, 255, 255, 0.05);
        font-weight: 500;
    }
    
    [data-testid="stSidebar"] [role="radiogroup"] label:hover {
        background: rgba(99, 179, 237, 0.1);
        border-color: rgba(99, 179, 237, 0.3);
        color: #63b3ed;
        transform: translateX(4px);
    }
    
    /* Header/Title Section */
    h1 {
        color: #ffffff !important;
        font-weight: 700 !important;
        font-size: 3.5rem !important;
        margin-bottom: 0.5rem !important;
        letter-spacing: -1px !important;
    }
    
    /* Subtitle */
    .subtitle {
        color: #94a3b8;
        font-size: 1.25rem;
        font-weight: 400;
        margin-bottom: 3rem;
        line-height: 1.6;
    }
    
    /* Badge Styling */
    .badge {
        background: rgba(99, 179, 237, 0.15);
        color: #63b3ed;
        padding: 8px 20px;
        border-radius: 50px;
        font-size: 14px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        border: 1px solid rgba(99, 179, 237, 0.3);
        margin-bottom: 2rem;
    }
    
    /* Feature Cards - Dark Glass Morphism */
    .feature-card {
        background: linear-gradient(135deg, rgba(255, 255, 255, 0.05) 0%, rgba(255, 255, 255, 0.02) 100%);
        backdrop-filter: blur(10px);
        padding: 2.5rem;
        border-radius: 20px;
        border: 1px solid rgba(255, 255, 255, 0.08);
        margin: 1.5rem 0;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
        overflow: hidden;
    }
    
    .feature-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 3px;
        background: linear-gradient(90deg, transparent, #63b3ed, transparent);
        opacity: 0;
        transition: opacity 0.3s ease;
    }
    
    .feature-card:hover {
        transform: translateY(-8px);
        border-color: rgba(99, 179, 237, 0.3);
        box-shadow: 0 20px 60px rgba(99, 179, 237, 0.15);
    }
    
    .feature-card:hover::before {
        opacity: 1;
    }
    
    .feature-card h3 {
        color: #ffffff;
        font-size: 1.5rem;
        font-weight: 700;
        margin-bottom: 1rem;
    }
    
    .feature-card p {
        color: #94a3b8;
        font-size: 1rem;
        line-height: 1.6;
        margin: 0;
    }
    
    /* Icon Containers */
    .icon-container {
        width: 60px;
        height: 60px;
        border-radius: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 28px;
        margin-bottom: 1.5rem;
    }
    
    .icon-blue {
        background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
    }
    
    .icon-purple {
        background: linear-gradient(135deg, #a855f7 0%, #9333ea 100%);
    }
    
    .icon-teal {
        background: linear-gradient(135deg, #14b8a6 0%, #0d9488 100%);
    }
    
    .icon-orange {
        background: linear-gradient(135deg, #f97316 0%, #ea580c 100%);
    }
    
    /* Gradient Buttons */
    .stButton > button {
        background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
        color: white;
        border: none;
        padding: 0.875rem 2.5rem;
        border-radius: 12px;
        font-weight: 600;
        font-size: 16px;
        transition: all 0.3s ease;
        box-shadow: 0 10px 30px rgba(59, 130, 246, 0.3);
        border: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 15px 40px rgba(59, 130, 246, 0.4);
        background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
    }
    
    /* Secondary Button */
    .secondary-btn {
        background: rgba(255, 255, 255, 0.05) !important;
        border: 1px solid rgba(255, 255, 255, 0.1) !important;
        color: #e2e8f0 !important;
        box-shadow: none !important;
    }
    
    .secondary-btn:hover {
        background: rgba(255, 255, 255, 0.08) !important;
        border-color: rgba(255, 255, 255, 0.2) !important;
    }
    
    /* Input Fields */
    .stTextInput > div > div > input,
    .stNumberInput > div > div > input,
    .stSelectbox > div > div {
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 10px;
        color: #e2e8f0;
        padding: 12px 16px;
        transition: all 0.3s ease;
    }
    
    .stTextInput > div > div > input:focus,
    .stNumberInput > div > div > input:focus {
        border-color: #63b3ed;
        box-shadow: 0 0 0 3px rgba(99, 179, 237, 0.1);
        background: rgba(255, 255, 255, 0.08);
    }
    
    /* Labels */
    label {
        color: #cbd5e1 !important;
        font-weight: 500 !important;
        font-size: 14px !important;
    }
    
    /* Metrics */
    [data-testid="stMetricValue"] {
        font-size: 2.5rem;
        font-weight: 700;
        color: #63b3ed;
    }
    
    [data-testid="stMetricLabel"] {
        color: #94a3b8;
        font-size: 0.95rem;
    }
    
    /* Success/Info/Warning Messages */
    .stSuccess, .stInfo, .stWarning {
        background: rgba(255, 255, 255, 0.05);
        border-radius: 12px;
        padding: 1.25rem;
        border-left: 4px solid;
        backdrop-filter: blur(10px);
    }
    
    .stSuccess {
        border-left-color: #10b981;
        color: #6ee7b7;
    }
    
    .stInfo {
        border-left-color: #3b82f6;
        color: #93c5fd;
    }
    
    /* Image Styling */
    img {
        border-radius: 20px;
        border: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    /* Divider */
    hr {
        margin: 3rem 0;
        border: none;
        height: 1px;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
    }
    
    /* Headings */
    h2, h3 {
        color: #ffffff !important;
        font-weight: 700 !important;
    }
    
    /* Paragraphs */
    p {
        color: #94a3b8;
    }
    
    /* Lists */
    ul li, ol li {
        color: #94a3b8;
        margin: 0.5rem 0;
    }
    
    /* Stats Grid */
    .stats-card {
        background: rgba(255, 255, 255, 0.03);
        padding: 1.5rem;
        border-radius: 12px;
        border: 1px solid rgba(255, 255, 255, 0.08);
        text-align: center;
    }
    
    .stats-number {
        font-size: 2rem;
        font-weight: 700;
        color: #63b3ed;
        display: block;
        margin-bottom: 0.5rem;
    }
    
    .stats-label {
        color: #94a3b8;
        font-size: 0.9rem;
    }
    
    /* Hero Section */
    .hero-section {
        text-align: center;
        padding: 3rem 0;
    }
    
    /* Feature Grid */
    .feature-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 1.5rem;
        margin: 2rem 0;
    }
</style>
""", unsafe_allow_html=True)

# --------------------------------------------------------
# HEADER SECTION
# --------------------------------------------------------
st.markdown("""
<div class='hero-section'>
    <div class='badge'>
        🧬 Advanced Genetic Intelligence
    </div>
    <h1>Unlock the Secrets of<br><span style='background: linear-gradient(135deg, #63b3ed 0%, #a855f7 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;'>Your Genome</span></h1>
    <p class='subtitle'>Cutting-edge genetic analysis platform powered by AI and advanced computational biology</p>
</div>
""", unsafe_allow_html=True)

# Action Buttons
col_btn1, col_btn2, col_btn3 = st.columns([1, 1, 1])
with col_btn2:
    if st.button("🚀 Start Analysis", key="start_btn", use_container_width=True):
        st.info("Navigate using the sidebar to begin your analysis")

st.markdown("<br>", unsafe_allow_html=True)

# --------------------------------------------------------
# FEATURE CARDS SECTION
# --------------------------------------------------------

# First Row - Main Features
col1, col2, col3 = st.columns(3)

with col1:
    st.markdown("""
    <div class='feature-card'>
        <div class='icon-container icon-blue'>🔗</div>
        <h3>Genetic Pathway Predictor</h3>
        <p>Analyze and predict complex genetic pathways with AI-powered insights</p>
    </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown("""
    <div class='feature-card'>
        <div class='icon-container icon-purple'>📊</div>
        <h3>Gene-Disease Graph</h3>
        <p>Visualize intricate connections between genes and diseases</p>
    </div>
    """, unsafe_allow_html=True)

with col3:
    st.markdown("""
    <div class='feature-card'>
        <div class='icon-container icon-teal'>📈</div>
        <h3>Gene Stability Index</h3>
        <p>Predict genetic stability with advanced computational models</p>
    </div>
    """, unsafe_allow_html=True)

# Second Row
col4, col5, col6 = st.columns(3)

with col4:
    st.markdown("""
    <div class='feature-card'>
        <div class='icon-container icon-orange'>🗺️</div>
        <h3>Genotype-to-Phenotype Mapper</h3>
        <p>Map genetic variations to observable traits and characteristics</p>
    </div>
    """, unsafe_allow_html=True)

with col5:
    st.markdown("""
    <div class='feature-card'>
        <div class='icon-container icon-blue'>🤖</div>
        <h3>ML Predictions</h3>
        <p>Train sophisticated machine learning models for mutation impact analysis</p>
    </div>
    """, unsafe_allow_html=True)

with col6:
    st.markdown("""
    <div class='feature-card'>
        <div class='icon-container icon-purple'>🧩</div>
        <h3>Pathway Analysis</h3>
        <p>Explore biological pathways using graph algorithms and network analysis</p>
    </div>
    """, unsafe_allow_html=True)

st.markdown("<br><br>", unsafe_allow_html=True)

# --------------------------------------------------------
# FEATURED SECTION - Genotype Mapper
# --------------------------------------------------------
st.markdown("### ⭐ Featured Tool: Genotype-Phenotype Mapper")
st.markdown("""
<div style='background: linear-gradient(135deg, rgba(99, 179, 237, 0.1) 0%, rgba(168, 85, 247, 0.1) 100%); 
            padding: 2.5rem; border-radius: 20px; border: 1px solid rgba(99, 179, 237, 0.2); margin: 2rem 0;
            backdrop-filter: blur(10px);'>
    <div style='display: flex; align-items: center; margin-bottom: 1.5rem; gap: 15px;'>
        <h3 style='color: #ffffff; margin: 0; flex-grow: 1; font-size: 1.75rem;'>Predict Phenotypes from Genetic Variants</h3>
        <span style='background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 0.4rem 1rem; border-radius: 50px; font-size: 0.85rem; font-weight: 700; letter-spacing: 0.5px;'>NEW</span>
    </div>
    <p style='color: #cbd5e1; margin: 1.5rem 0; font-size: 1.05rem; line-height: 1.7;'>Our latest AI-powered tool analyzes genetic mutations to predict phenotypic outcomes including cancer susceptibility, metabolic disorders, and resistance variants.</p>
    <div style='display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; margin-top: 2rem;'>
        <div class='stats-card'>
            <span class='stats-number'>99%</span>
            <span class='stats-label'>Prediction Accuracy</span>
        </div>
        <div class='stats-card'>
            <span class='stats-number'>4</span>
            <span class='stats-label'>Phenotype Classes</span>
        </div>
        <div class='stats-card'>
            <span class='stats-number'>5</span>
            <span class='stats-label'>Supported Genes</span>
        </div>
        <div class='stats-card'>
            <span class='stats-number'>&lt;0.1s</span>
            <span class='stats-label'>Prediction Time</span>
        </div>
    </div>
</div>
""", unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# --------------------------------------------------------
# KEY BENEFITS SECTION
# --------------------------------------------------------
st.markdown("### ✨ Why Choose Genofy?")

benefits_col1, benefits_col2 = st.columns(2)

with benefits_col1:
    st.markdown("""
    <div style='color: #cbd5e1; font-size: 1rem; line-height: 2;'>
    
    • 🎯 <strong style='color: #ffffff;'>High Accuracy:</strong> State-of-the-art ML algorithms<br>
    • 🚀 <strong style='color: #ffffff;'>Fast Processing:</strong> Get results in seconds<br>
    • 📊 <strong style='color: #ffffff;'>Rich Visualizations:</strong> Interactive graphs and charts
    
    </div>
    """, unsafe_allow_html=True)

with benefits_col2:
    st.markdown("""
    <div style='color: #cbd5e1; font-size: 1rem; line-height: 2;'>
    
    • 🔬 <strong style='color: #ffffff;'>Research-Grade:</strong> Validated methodologies<br>
    • 💾 <strong style='color: #ffffff;'>Easy Data Upload:</strong> Support for CSV/XLSX formats<br>
    • 🌐 <strong style='color: #ffffff;'>Comprehensive Analysis:</strong> From genes to pathways
    
    </div>
    """, unsafe_allow_html=True)

# --------------------------------------------------------
# FOOTER
# --------------------------------------------------------
st.markdown("<br><br>", unsafe_allow_html=True)
st.markdown("""
<div style='text-align: center; color: #64748b; padding: 2rem 0; border-top: 1px solid rgba(255, 255, 255, 0.05);'>
    <p style='margin: 0;'>© 2025 Genofy - Advanced Genetic Intelligence Platform</p>
</div>
""", unsafe_allow_html=True)