# make_synthetic_geno_biased.py
import pandas as pd, random

genes=['TP53','BRCA1','EGFR','KRAS','MYC']
mutations=['A>T','G>C','C>T','T>G']
phenos=['Normal','Cancer_Susceptibility','Metabolic_Disorder','Resistance_Variant']

rows=[]
for i in range(500):
    gene=random.choice(genes)
    mut=random.choice(mutations)
    expr=round(random.uniform(0,1),3)
    impact=round(random.uniform(0,1),3)

    # add simple pattern: high expr + high impact → cancer
    if impact>0.7 and expr>0.7:
        label='Cancer_Susceptibility'
    elif impact<0.3 and expr<0.3:
        label='Normal'
    elif expr>0.5 and impact<0.5:
        label='Metabolic_Disorder'
    else:
        label='Resistance_Variant'
    
    seq=f"{gene[:3]}_{i}->{mut}"
    rows.append([gene,mut,seq,expr,impact,label])

df=pd.DataFrame(rows,columns=['Gene','Mutation','Mutation_Seq','Expression_Level','Impact_Score','Phenotype_Label'])
df.to_csv('genotype_train.csv', index=False)
print("Biased synthetic data created!")
