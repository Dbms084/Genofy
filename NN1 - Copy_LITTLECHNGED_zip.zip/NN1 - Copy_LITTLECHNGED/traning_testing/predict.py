# predict.py
# -----------------------------
# Loads trained model, scaler, and feature list.
# Makes predictions for new test data.
# -----------------------------

import pandas as pd
import joblib
import os

# 1️⃣ Load Model, Scaler, and Feature Names
def load_components(model_dir='models'):
    model_path = os.path.join(model_dir, 'model.pkl')
    scaler_path = os.path.join(model_dir, 'scaler.pkl')
    features_path = os.path.join(model_dir, 'feature_names.pkl')

    if not all(os.path.exists(p) for p in [model_path, scaler_path, features_path]):
        raise FileNotFoundError("❌ One or more model files not found. Please train the model first!")

    model = joblib.load(model_path)
    scaler = joblib.load(scaler_path)
    feature_names = joblib.load(features_path)

    print("✅ Model, Scaler, and Feature Names loaded successfully!")
    return model, scaler, feature_names


# 2️⃣ Load and Prepare Test Data
def prepare_data(test_csv_path, feature_names):
    if not os.path.exists(test_csv_path):
        raise FileNotFoundError(f"❌ Test dataset not found at {test_csv_path}")

    df = pd.read_excel("C:/Users/dhrit/Downloads/new/data/test_genetic_data.xlsx")
    print("📂 Test Data Loaded Successfully! Shape:", df.shape)

    # Drop text columns not used for training
    df = df.drop(columns=['Gene', 'Sequence', 'Impact_Score'], errors='ignore')

    # Apply same one-hot encoding as training
    df = pd.get_dummies(df, columns=[col for col in ['Mutation', 'Category'] if col in df.columns], drop_first=True)

    # Reindex to match training feature order (fill missing with 0)
    df = df.reindex(columns=feature_names, fill_value=0)

    return df


# 3️⃣ Predict Function
def predict(model, scaler, df):
    X_scaled = scaler.transform(df)
    predictions = model.predict(X_scaled)
    df["Predicted_Impact_Score"] = predictions
    return df


# 4️⃣ Main Function
if __name__ == "__main__":
    # Path to test CSV
    test_csv_path = "C:/Users/dhrit/Downloads/new/data/test_genetic_data.xlsx"  # ✅ Replace with your test file

    # Load components
    model, scaler, feature_names = load_components()

    # Prepare data
    df_prepared = prepare_data(test_csv_path, feature_names)

    # Predict
    results = predict(model, scaler, df_prepared)

    # Save predictions
    output_path = "C:/Users/dhrit/Downloads/new/data/predictions.csv"
    results.to_csv(output_path, index=False)
    print(f"✅ Predictions saved successfully to: {output_path}")
    print(results.head())
