# traning_testing/predict_genotype_phenotype.py
import joblib, numpy as np, os

# --- ✅ Always load model & encoders from 'new/models' ---
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # points to 'new/'
MODEL_DIR = os.path.join(BASE_DIR, "models")

MODEL_PATH = os.path.join(MODEL_DIR, "genotype_phenotype_model.pkl")
ENCODER_PATH = os.path.join(MODEL_DIR, "genotype_phenotype_encoders.pkl")

def load_model():
    model = joblib.load(MODEL_PATH)
    encoders = joblib.load(ENCODER_PATH)
    return model, encoders

def predict_trait(gene_id, mutation, expression_level, impact_score):
    model, encoders = load_model()

    le_gene = encoders['le_gene']
    le_mut = encoders['le_mut']
    le_label = encoders['le_label']
    scaler = encoders['scaler']

    # Handle unseen genes or mutations gracefully
    try:
        gene_encoded = le_gene.transform([gene_id])[0]
    except:
        gene_encoded = -1

    try:
        mut_encoded = le_mut.transform([mutation])[0]
    except:
        mut_encoded = -1

    features = np.array([[gene_encoded, mut_encoded, expression_level, impact_score]])
    features_scaled = scaler.transform(features)

    probs = model.predict_proba(features_scaled)[0]
    pred_idx = np.argmax(probs)
    pred_label = le_label.inverse_transform([pred_idx])[0]
    confidence = probs[pred_idx]

    # Return full probability dictionary for chart display
    prob_dict = dict(zip(le_label.classes_, probs))
    return pred_label, confidence, prob_dict
