# training_testing/train_genotype_phenotype.py
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import joblib, os

# --- ✅ Always save inside 'new/models' relative to this script ---
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # points to 'new/'
MODEL_DIR = os.path.join(BASE_DIR, "models")
DATA_PATH = os.path.join(BASE_DIR, "data", "genotype_train.csv")

os.makedirs(MODEL_DIR, exist_ok=True)

def train_genotype_phenotype_model():
    # Load dataset
    df = pd.read_csv(DATA_PATH)
    df.dropna(inplace=True)

    # Rename columns to be consistent
    df.rename(columns={
        'Gene': 'gene_id',
        'Mutation': 'mutation',
        'Expression_Level': 'expression_level',
        'Impact_Score': 'impact_score',
        'Phenotype_Label': 'label'
    }, inplace=True)

    # Encode categorical columns
    le_gene = LabelEncoder()
    le_mut = LabelEncoder()
    le_label = LabelEncoder()

    df['gene_encoded'] = le_gene.fit_transform(df['gene_id'])
    df['mutation_encoded'] = le_mut.fit_transform(df['mutation'])
    df['label_encoded'] = le_label.fit_transform(df['label'])

    X = df[['gene_encoded', 'mutation_encoded', 'expression_level', 'impact_score']]
    y = df['label_encoded']

    # Scale numerical features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Split into training and test sets
    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42, stratify=y
    )

    # Train model
    model = GradientBoostingClassifier(n_estimators=300, learning_rate=0.05, random_state=42)
    model.fit(X_train, y_train)

    # --- Evaluate model ---
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)

    print("\nModel trained successfully!")
    print(f"Accuracy on test data: {acc*100:.2f}%")
    print("\nDetailed classification report:")
    print(classification_report(y_test, y_pred, target_names=le_label.classes_))
    print("Confusion matrix:\n", confusion_matrix(y_test, y_pred))

    # --- Save model + encoders ---
    model_path = os.path.join(MODEL_DIR, "genotype_phenotype_model.pkl")
    encoder_path = os.path.join(MODEL_DIR, "genotype_phenotype_encoders.pkl")

    joblib.dump(model, model_path)
    joblib.dump({
        'le_gene': le_gene,
        'le_mut': le_mut,
        'le_label': le_label,
        'scaler': scaler
    }, encoder_path)

    print(f"\nModel saved at: {model_path}")
    print(f"Encoders saved at: {encoder_path}")

if __name__ == "__main__":
    train_genotype_phenotype_model()
