# train_model.py - REDUCED BIAS VERSION
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import mean_squared_error, r2_score
import joblib
import os

def load_data(file_path):
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"❌ Dataset not found at {file_path}")
    df = pd.read_csv(file_path)
    print("✅ Data Loaded Successfully!")
    print("📊 Dataset Shape:", df.shape)
    return df

def preprocess_data(df):
    """
    Standard preprocessing function for compatibility
    """
    df = df.drop(columns=['Gene', 'Sequence'], errors='ignore')
    X = df.drop(columns=['Impact_Score'])
    y = df['Impact_Score']

    # One-hot encode categorical columns (Mutation, Category)
    categorical_cols = [col for col in ['Mutation', 'Category'] if col in X.columns]
    X = pd.get_dummies(X, columns=categorical_cols, drop_first=True)

    # Scale numerical features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    return X_scaled, y, scaler, X.columns.tolist()

def preprocess_data_reduced_bias(df):
    """
    Preprocessing that reduces category feature dominance
    """
    df = df.drop(columns=['Gene', 'Sequence'], errors='ignore')
    X = df.drop(columns=['Impact_Score'])
    y = df['Impact_Score']

    # Use Label Encoding instead of One-Hot for categories
    categorical_cols = [col for col in ['Mutation', 'Category'] if col in X.columns]
    label_encoders = {}
    
    for col in categorical_cols:
        le = LabelEncoder()
        X[col] = le.fit_transform(X[col])
        label_encoders[col] = le

    # Create interaction features to spread importance
    X['Expr_GC_Interaction'] = X['Expression_Level'] * X['GC_Content'] / 100
    X['Expr_MutFreq_Interaction'] = X['Expression_Level'] * X['Mutation_Frequency']
    X['GC_MutFreq_Interaction'] = X['GC_Content'] * X['Mutation_Frequency']
    
    # Add polynomial features
    X['Expression_squared'] = X['Expression_Level'] ** 2
    X['GC_squared'] = X['GC_Content'] ** 2
    
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    return X_scaled, y, scaler, X.columns.tolist(), label_encoders

def train_model(X, y, feature_names):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Use parameters that reduce feature dominance
    model = RandomForestRegressor(
        n_estimators=200,
        max_depth=15,
        min_samples_split=5,
        min_samples_leaf=3,
        max_features=0.7,  # Use only 70% of features per tree
        max_samples=0.8,   # Use only 80% of data per tree
        random_state=42
    )
    
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    r2 = r2_score(y_test, y_pred)

    print("✅ Model Training Completed")
    print(f"📊 RMSE: {rmse:.4f}")
    print(f"📈 R² Score: {r2:.4f}")

    # Feature Importance Analysis
    feature_importance = pd.DataFrame({
        'feature': feature_names,
        'importance': model.feature_importances_
    }).sort_values('importance', ascending=False)
    
    print("\n🔍 Feature Importance Distribution:")
    print(feature_importance)
    
    # Check if we reduced category dominance
    category_features = [f for f in feature_names if 'Category' in str(f)]
    if category_features:
        cat_importance = feature_importance[feature_importance['feature'].isin(category_features)]['importance'].sum()
        print(f"\n📊 Category features now account for {cat_importance:.1%} of total importance")
    
    return model, rmse, r2

def save_model(model, scaler, feature_names, label_encoders=None):
    os.makedirs('models', exist_ok=True)
    joblib.dump(model, 'models/model.pkl')
    joblib.dump(scaler, 'models/scaler.pkl')
    joblib.dump(feature_names, 'models/feature_names.pkl')
    if label_encoders:
        joblib.dump(label_encoders, 'models/label_encoders.pkl')
    print("💾 All model components saved in 'models/' folder!")

if __name__ == "__main__":
    data_path = "C:/Users/dhrit/Downloads/new/data/genetic_dataset_ml.csv"
    df = load_data(data_path)
    
    # Data analysis
    print("\n🔍 Data Analysis:")
    print("Category-Impact Relationship:")
    print(df.groupby('Category')['Impact_Score'].agg(['mean', 'count']))
    
    # Preprocess with reduced bias
    X_scaled, y, scaler, feature_names, label_encoders = preprocess_data_reduced_bias(df)
    
    print(f"\n📊 New feature set: {len(feature_names)} features")
    print("Features:", feature_names)
    
    # Train model
    model, rmse, r2 = train_model(X_scaled, y, feature_names)
    save_model(model, scaler, feature_names, label_encoders)