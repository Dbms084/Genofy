import pandas as pd
import networkx as nx
import os
from graph_utils import find_shortest_path, analyze_path, visualize_path


def load_graph_data(file_path):
    """Load gene interaction dataset and create a weighted graph."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"❌ File not found: {file_path}")
    
    df = pd.read_csv(file_path)
    print(f"✅ Data Loaded Successfully! Shape: {df.shape}")

    # Create directed graph
    G = nx.DiGraph()

    # Add weighted edges
    for _, row in df.iterrows():
        weight = row['Path_Distance'] + row['Energy_Cost'] - (0.5 * row['Reliability_Score'])
        G.add_edge(row['Gene'], row['Protein'], weight=weight)

    print("🧬 Sample Genes:", list(df['Gene'].unique())[:10])
    print("🧫 Sample Proteins:", list(df['Protein'].unique())[:10])
    print("🧠 Total Nodes in Graph:", len(G.nodes))
    
    return G, df


if __name__ == "__main__":
    # ✅ Path to dataset
    data_path = "C:/Users/dhrit/Downloads/new/data/gene_interaction_dsa.csv"

    # ✅ Load data + build graph
    G, df = load_graph_data(data_path)

    # ✅ Choose start and target from your dataset
    start = "PTEN"      # Example gene (make sure it exists in df['Gene'])
    target = "AKT"      # Example protein (make sure it exists in df['Protein'])

    # ✅ Find shortest path
    path, distance = find_shortest_path(G, start, target)

    if path:
        print("\n🧬 Shortest Biological Path Found:")
        print(" → ".join(path))
        print(f"🔹 Total Path Distance (Weighted): {distance:.3f}")

        # ✅ Analyze and visualize path
        analysis = analyze_path(G, path)
        print("\n📈 Path Analysis Summary:")
        for key, value in analysis.items():
            print(f"{key}: {value}")

        visualize_path(G, path)
    else:
        print("⚠️ No valid path found between the given nodes.")
