import networkx as nx
import matplotlib.pyplot as plt
import numpy as np

# -----------------------------------------------
# 🔹 Shortest Path Finder (already used in main.py)
# -----------------------------------------------
def find_shortest_path(G, start_gene, target_protein):
    try:
        path = nx.dijkstra_path(G, source=start_gene, target=target_protein, weight='weight')
        distance = nx.dijkstra_path_length(G, source=start_gene, target=target_protein, weight='weight')
        return path, distance
    except nx.NodeNotFound as e:
        print(f"⚠️ Node not found: {e}")
        return None, None
    except nx.NetworkXNoPath:
        print(f"🚫 No path found between {start_gene} and {target_protein}")
        return None, None


# -----------------------------------------------
# 📈 Path Analysis — Biological Interpretation
# -----------------------------------------------
def analyze_path(G, path):
    if not path or len(path) < 2:
        return {"Error": "Invalid path"}

    total_energy = 0
    total_reliability = 0
    total_distance = 0
    edge_count = len(path) - 1

    # Extract all edges and compute weighted features
    for i in range(edge_count):
        gene = path[i]
        protein = path[i + 1]
        if G.has_edge(gene, protein):
            edge_data = G[gene][protein]
            weight = edge_data.get('weight', 0)
            total_distance += weight

            # Simulated or stored biological factors
            total_energy += abs(np.sin(weight)) * 5 + 2      # mock energy cost pattern
            total_reliability += max(0, 1 - np.log1p(weight / 10)) * 100  # mock reliability %

    avg_energy = total_energy / edge_count
    avg_reliability = total_reliability / edge_count

    analysis = {
        "node_count": len(path),
        "edge_count": edge_count,
        "total_weight": round(total_distance, 3),
        "average_weight": round(total_distance / edge_count if edge_count > 0 else 0, 3),
        "total_energy_cost": round(total_energy, 3),
        "average_energy_cost": round(avg_energy, 3),
        "average_reliability_percent": round(avg_reliability, 2)
    }

    return analysis


# -----------------------------------------------
# 🧫 Graph Visualization
# -----------------------------------------------
def visualize_path(G, path=None):
    fig, ax = plt.subplots(figsize=(10, 7))
    
    pos = nx.spring_layout(G, seed=42)  # consistent layout

    # Draw all edges in light gray
    nx.draw(G, pos, with_labels=True, node_size=1200, node_color="#FDEEDC", 
            font_size=9, font_weight='bold', edge_color='lightgray', ax=ax)

    # Highlight path if available
    if path and len(path) > 1:
        path_edges = list(zip(path, path[1:]))
        nx.draw_networkx_nodes(G, pos, nodelist=path, node_color="#F5CBA7", ax=ax)
        nx.draw_networkx_edges(G, pos, edgelist=path_edges, width=2.5, edge_color="#D35400", ax=ax)
        nx.draw_networkx_labels(G, pos, labels={node: node for node in path}, 
                                font_color='black', font_size=10, font_weight='bold', ax=ax)

        ax.set_title("🧬 Shortest Biological Pathway Highlighted", fontsize=14)
    else:
        ax.set_title("🧬 Gene-Protein Interaction Network", fontsize=14)

    plt.tight_layout()
    return fig
